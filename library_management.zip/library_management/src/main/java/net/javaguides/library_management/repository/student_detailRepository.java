package net.javaguides.library_management.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.library_management.entity.student_detail;

public interface student_detailRepository extends JpaRepository<student_detail, Long>{

}
