package net.javaguides.library_management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.library_management.entity.student_detail;
import net.javaguides.library_management.exception.ResourceNotFound;
import net.javaguides.library_management.repository.student_detailRepository;

@RestController
@RequestMapping
public class studentController {
	@Autowired
	private student_detailRepository Student_detailRepository;
	@GetMapping
	public List<student_detail>getAllstudent_detail(){
		return this.Student_detailRepository.findAll();
	}
	@GetMapping("/{id}")
	public student_detail getStudent_detailId(@PathVariable (value = "id") long student_detailId) {
		return this.Student_detailRepository.findById(student_detailId)
				.orElseThrow(()->new ResourceNotFound("user not found with id:" + student_detailId));
}
	@PostMapping
	public student_detail createStudent_detailRepository(@RequestBody student_detail Student_detail) {
		
		return this.Student_detailRepository.save(Student_detail);
	}

	//update Members
@PutMapping("/{id}")
public student_detail updateMembers(@RequestBody student_detail Student_detail,@PathVariable("id") long student_detailId) {
	student_detail existingMembers =  this.Student_detailRepository.findById(student_detailId)
		.orElseThrow(()->new ResourceNotFound("user not found with id:" + student_detailId));
existingMembers.setFirstname(student_detail.getFirstname());
existingMembers.setLastname(student_detail.getLastname());
existingMembers.setEmail(student_detail.getEmail());
existingMembers.setStream(student_detail.getStream());
return this.Student_detailRepository.save(existingMembers);
}
//delete Members by id
@DeleteMapping("/{id}")
public ResponseEntity<student_detail> deleteMembers(@PathVariable ("id")long membersId){
	student_detail existingMembers =  this.Student_detailRepository.findById(membersId)
		.orElseThrow(()->new ResourceNotFound("user not found with id:" + membersId));
this.Student_detailRepository.delete(existingMembers);
return ResponseEntity.ok().build();


}
}
